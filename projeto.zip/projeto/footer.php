<!-- Footer-->
        <footer class="py-3 custom-footer">
            <div class="container"><p class="m-0 text-center" style="color: #138d77">Copyright &copy; Desenvolvido por Milena Pestana 2025</p></div>
            <style>
                .custom-footer {
                    background-color: #a5e8d3; 
                    color: white;
                }
            </style>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
